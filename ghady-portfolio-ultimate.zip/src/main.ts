const menuBtn = document.getElementById("menuBtn") as HTMLButtonElement | null;
const navMenu = document.getElementById("navMenu") as HTMLElement | null;

menuBtn?.addEventListener("click", () => {
  navMenu?.classList.toggle("active");
});

document.querySelectorAll<HTMLAnchorElement>("nav a").forEach((link) => {
  link.addEventListener("click", () => {
    navMenu?.classList.remove("active");
  });
});

const revealElements = document.querySelectorAll<HTMLElement>(".reveal");

const revealObserver = new IntersectionObserver(
  (entries: IntersectionObserverEntry[]) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        (entry.target as HTMLElement).classList.add("visible");
      }
    });
  },
  { threshold: 0.15 }
);

revealElements.forEach((element) => revealObserver.observe(element));
