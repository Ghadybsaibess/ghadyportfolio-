# Ghady Bsaibess Ultimate Portfolio

This portfolio uses:
- HTML
- CSS
- JavaScript
- TypeScript source code
- Node.js tooling

## Important for GitHub Pages

GitHub Pages can open the website directly because `dist/main.js` is already included.

Upload these files and folders:
- `index.html`
- `style.css`
- `dist`
- `src`
- `package.json`
- `tsconfig.json`
- `bigfive-test-picture.png`

Then go to:
Settings > Pages > Deploy from a branch > main > /root > Save
