# Ghady Bsaibess Professional Portfolio

This is a professional portfolio website made with HTML, CSS, and JavaScript.

## Upload to GitHub Pages

Upload these files to your repository:
- index.html
- style.css
- script.js
- bigfive-test-picture.png

Then go to Settings > Pages:
- Source: Deploy from a branch
- Branch: main
- Folder: /root
- Save
