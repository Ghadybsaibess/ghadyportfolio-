# Ghady Bsaibess Portfolio

A professional static portfolio website built with HTML, CSS, and JavaScript.

## How to publish with GitHub Pages

1. Upload all files to your GitHub repository.
2. Go to Settings.
3. Click Pages.
4. Select Branch: main.
5. Select Folder: /root.
6. Click Save.

Your website will appear at:

https://yourusername.github.io/repository-name/
